# Duckumenters Dali

**Duckumenters Dali** es una aplicación web desarrollada en Python utilizando el framework Flask. Esta aplicación permite a los usuarios generar comunicados automáticos interactuando con la API de Gemini, un modelo de lenguaje generativo. El objetivo del proyecto es facilitar la creación de comunicados internos en una organización de manera rápida y eficiente.

## Características

- Generación automática de comunicados basados en entradas de texto del usuario.
- Interfaz web sencilla e intuitiva.
- Integración con la API de Gemini para procesamiento de lenguaje natural.
- Manejo de errores y validación de entradas.

## Tecnologías Utilizadas

- **Python 3**
- **Flask**
- **HTML y CSS**
- **API de Gemini (Google Generative Language API)**
- **Git y GitHub**

## Instalación

Sigue estos pasos para instalar y ejecutar el proyecto en tu máquina local:

### Requisitos Previos

- Python 3 instalado en tu sistema.
- pip (gestor de paquetes de Python).
- Una clave de API válida para la API de Gemini.

### Pasos de Instalación

1. **Clona el repositorio:**

   ```bash
   git clone https://github.com/helbert-marroquin/rep_DuckumentersDali.git
