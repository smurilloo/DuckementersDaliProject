
import subprocess
from flask import Flask, render_template, request, url_for
import json
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
import requests
import time
import re
import gc  # Importar el módulo para la recolección de basura


# Instanciar la aplicación Flask
app = Flask(__name__)
app.config["SECRET_KEY"] = "you-will-never-guess"

# Configuración para el correo
SMTP_SERVER = "smtp.gmail.com"  # Servidor SMTP
SMTP_PORT = 587  # Puerto SMTP
EMAIL_ADDRESS = "samuel.murillo@bluetab.net"  # Cambiar a tu dirección de correo
EMAIL_PASSWORD = "xgsccuwkdtyfrfir"  # Cambiar a tu contraseña (o usar una contraseña de aplicación si usas 2FA)
# Configurar el timeout
TIMEOUT = 120  # Tiempo máximo en segundos para la conexión y operaciones SMTP

def clean_text(text):
    """Limpia el texto eliminando asteriscos y otros caracteres no deseados."""
    cleaned_text = text.replace("**", "").strip()  # Eliminar asteriscos y espacios adicionales
    return cleaned_text

def clean_and_extract_emails(email_input):
    """Limpiar el texto y extraer las direcciones de correo electrónico, asegurando que no contengan los símbolos <, > ni comas ,."""

    # Primero eliminamos los símbolos < y > de los correos electrónicos
    email_input = email_input.replace('<', '').replace('>', '')  # Eliminar los símbolos < y >

    # Reemplazamos las comas (,) por punto y coma (;)
    email_input = email_input.replace(',', ';')

    # Ahora dividimos el texto por punto y coma (;) y limpiamos espacios extra
    email_list = [email.strip() for email in email_input.split(';')]

    # Usamos una expresión regular para verificar y extraer direcciones de correo válidas
    email_pattern = r'[\w\.-]+@[\w\.-]+\.[a-zA-Z]{2,}'  # Expresión regular para correos válidos

    # Filtramos y extraemos las direcciones válidas
    emails = [email for email in email_list if re.match(email_pattern, email)]

    return emails

#El formato de la respuesta está en html, no texto plano.
def pimp_my_reply(input_text):
    recipient = "<strong>Querido/a Bluetaber:</strong><br><br>"
    # force string type in input
    text = str(input_text)
    
    # clean 
    text = text.replace("\n\n","\n")
    
    #Quitar prompt original del mensaje
    if ("Asunto:" in text) or ("De:" in text):
        text = text.replace(re.findall("Asunto:.*?\n", text)[0], "")
    
    #Quitar saludo del mensaje
    if "Estimado candidato:" in text:
        text = text.replace("Estimado candidato:", "")
    elif "De: Bluetab Solutions" in text:
        text = text.replace("De: Bluetab Solutions","")
    else:
        pass
    
    #Quitar despedida del mensaje
    if "Atentamente,\nBluetab Solutions" in text:
        text = text.replace(re.findall("Atentamente,\nBluetab Solutions", text)[0], "")
    
    #Mandar mensaje
    bye_text = '<br>Atentamente,<br>Bluetab Solutions<br>'
    output_text = recipient + text + bye_text
    return output_text


@app.route("/", methods=["GET", "POST"])
def index():
    """Página principal con formulario para enviar texto y obtener la respuesta de Gemini"""
    bot_reply = None  # Variable para almacenar la respuesta del bot
    comunicado_tipo = None  # Variable para almacenar el tipo de comunicado

    if request.method == "POST":
        # Obtener el texto del usuario y el correo desde el formulario
        user_input = request.form.get("user_input", "")
        user_email = request.form.get("user_email", "")

        # Asegurarse de que el texto esté correctamente codificado
        user_input = user_input.encode('utf-8').decode('utf-8')

        # Limpiar y extraer los correos electrónicos desde la entrada del usuario
        email_list = clean_and_extract_emails(user_email)

        meta_prompt = f"""
You are an assistant specialized in creating emails for Human Resources. Your task is to generate an email in plain text, without special characters, and completely in Spanish.

Instructions:
The message does not contain the original prompt.
The message has a formal and direct tone.
The message is brief but informative.
The message does not include any greeting.
Make sure to include any relevant details that may be missing (for example: date, time, place, reason).
If the date is not included, use 'next Friday'.
If the time is not included, use 'around 5pm local time'.
If the sender is not included, use 'Bluetab Solutions'.
If the place is not included, use 'in our offices'.
Ignore recipient unless specified.
Write a clear and professional email based on the following brief description of the objective:
{user_input}
"""
        curl_command = [
            "curl",
            "-H", "Content-Type: application/json",
            "-d", f'{{"contents":[{{"parts":[{{"text":"{meta_prompt}"}}]}}]}}',
            "-X", "POST",
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=AIzaSyD4DG2T5KlFUK9ohBzsO4Jf99uye_7XXJE"
        ]

        try:
            # Ejecutar el comando curl usando subprocess
            result = subprocess.run(curl_command, text=True, capture_output=True, encoding='utf-8')

            # Comprobar si la solicitud fue exitosa
            if result.returncode == 0:
                # La respuesta está en result.stdout, procesarla
                response_data = json.loads(result.stdout)

                # Verificar si la respuesta contiene el texto generado
                if "candidates" in response_data:
                    # Extraer el texto generado por el modelo
                    bot_reply = response_data["candidates"][0]["content"]["parts"][0]["text"]
                    # Limpiar el texto generado
                    bot_reply = clean_text(bot_reply)
                    # Dar formato al texto
                    try:
                        bot_reply = pimp_my_reply(bot_reply)
                    except Exception as e:
                        print(e)

                    # Realizar la solicitud para generar la imagen en Hugging Face (usando el mismo prompt)
                    image_data = generate_image(user_input)

                    # Si se proporcionaron correos electrónicos y se generó una imagen, enviar los correos
                    if email_list and image_data:
                        for email in email_list:
                            enviar_correo(email, bot_reply, image_data)  # Enviamos el mensaje y la imagen
                            print(f"Correo enviado a {email} con el mensaje: {bot_reply}")

                else:
                    bot_reply = "Lo siento, no pude procesar tu solicitud."

            else:
                bot_reply = f"Error en la solicitud: {result.stderr}"

        except Exception as e:
            bot_reply = f"Error: {str(e)}"

    return render_template("index.html", bot_reply=bot_reply)


def generate_image(prompt):
    """Generar una imagen usando la API de Hugging Face y retornar los datos de la imagen en memoria."""
    try:
        # Definir el endpoint y la clave de la API para Hugging Face
        url = "https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-2"
        headers = {
            "Authorization": "Bearer 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",  # Asegúrate de que este token sea válido
            "Content-Type": "application/json"
        }
        data = {
            "inputs": prompt
        }

        while True:  # Bucle que sigue intentando hasta recibir una respuesta exitosa
            # Realizar la solicitud POST para generar la imagen
            response = requests.post(url, headers=headers, json=data)

            if response.status_code == 200:
                # Si la respuesta es exitosa, obtener los datos binarios de la imagen
                img_data = response.content
                return img_data
            elif response.status_code == 503:
                # Si el modelo está cargando, intentar de nuevo después de un tiempo de espera
                try:
                    error_data = response.json()  # Intentar parsear la respuesta como JSON
                    if "error" in error_data and "loading" in error_data["error"]:
                        estimated_time = error_data["error"].get("estimated_time", 0)
                        print(f"El modelo está cargando, tiempo estimado de espera: {estimated_time} segundos.")
                        time.sleep(estimated_time)  # Esperar el tiempo estimado antes de reintentar
                    else:
                        # Si el error no es el esperado, salir del bucle
                        print(f"Error no esperado: {response.text}")
                        return None
                except ValueError:  # Si no se puede parsear el JSON correctamente
                    print(f"Error en la respuesta: {response.text}")
                    return None
            else:
                # Si se recibe otro tipo de error, imprimir el mensaje y salir
                print(f"Error en la solicitud a Hugging Face: {response.status_code}, {response.text}")
                return None

    except Exception as e:
        print(f"Error al generar la imagen: {e}")
        return None




def enviar_correo(destinatario, mensaje, image_data):
    """Enviar el correo con diseño HTML personalizado y una imagen generada al final."""
    try:
        # Crear el mensaje del correo
        msg = MIMEMultipart()
        msg["From"] = EMAIL_ADDRESS
        msg["To"] = destinatario
        msg["Subject"] = "Comunicado Interno Generado Automáticamente"

        # Construir el contenido HTML con el diseño proporcionado y el pie de página adicional
        with open("./templates/Template_correo.txt",encoding ="UTF-8") as my_file:
            html_template = my_file.read()

        html_content = html_template.replace("{mensaje}", mensaje)

        # Agregar el contenido HTML al correo
        msg.attach(MIMEText(html_content, "html"))

        # Adjuntar la imagen generada en memoria
        image_attachment = MIMEImage(image_data)
        image_attachment.add_header('Content-ID', '<image1>')  # Usar el mismo CID en el HTML
        msg.attach(image_attachment)

        # Enviar el correo usando el servidor SMTP
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=TIMEOUT) as server:
            server.starttls()  # Establece una conexión segura
            server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)  # Inicia sesión con tu correo y contraseña
            server.send_message(msg)  # Envía el correo

        print(f"Correo enviado exitosamente a {destinatario}")

    except Exception as e:
        print(f"Error al enviar correo: {e}")

    finally:
        # Liberar memoria después de cada envío de correo
        gc.collect()  # Llamada para liberar memoria no utilizada





if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)



##telnet smtp.gmail.com 587
